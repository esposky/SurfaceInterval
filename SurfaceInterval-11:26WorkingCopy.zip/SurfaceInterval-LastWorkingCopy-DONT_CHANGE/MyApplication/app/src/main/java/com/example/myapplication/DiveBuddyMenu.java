package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.otherjavafiles.DatabaseHelper;
import com.example.otherjavafiles.DivePartner;
import com.example.otherjavafiles.WildLife;
import com.example.otherjavafiles.WildLifeList;

public class DiveBuddyMenu extends AppCompatActivity {
    private static  final String MY_PREFS = "MyPrefsFile";
    private static DivePartner divePartner;

    Button back, addnew_divebuddy;
    ListView lvDiveBuddy;
    ArrayAdapter customArrayAdapter;
    SharedPreferences sharedPreferences;
    String userID;
    DatabaseHelper databaseHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dive_buddy_menu);

        addnew_divebuddy = (Button)findViewById(R.id.btnAddDiveBuddy);
        back = (Button) findViewById(R.id.back_to_otherDetails9);
        lvDiveBuddy = findViewById(R.id.lvDiveBuddy);
        sharedPreferences = this.getSharedPreferences(MY_PREFS, MODE_PRIVATE);
        userID = sharedPreferences.getString("userID", "Nothing");
        databaseHelper = new DatabaseHelper(DiveBuddyMenu.this);

        showAllBuddies(databaseHelper);

        lvDiveBuddy.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                divePartner = (DivePartner) parent.getItemAtPosition(position);
                Toast.makeText(DiveBuddyMenu.this, divePartner.toString() + " was the selected Buddy.", Toast.LENGTH_SHORT).show();
            }
        });

        addnew_divebuddy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),DivingBuddy.class);
                startActivity(intent);
            }
        });


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    protected void onRestart() {
        super.onRestart();
        showAllBuddies(databaseHelper);
    }

    private void showAllBuddies(DatabaseHelper databaseHelper2) {
        customArrayAdapter = new ArrayAdapter<>(DiveBuddyMenu.this, android.R.layout.simple_expandable_list_item_1, databaseHelper2.getBuddy(userID));
        lvDiveBuddy.setAdapter(customArrayAdapter);
    }

    public static DivePartner getData() {
        return divePartner;
    }
}