package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.otherjavafiles.DatabaseHelper;
import com.example.otherjavafiles.SingleLogTest;
import com.example.otherjavafiles.WildLife;
import com.example.otherjavafiles.WildLifeList;

public class SingleLogEquipmentPage extends AppCompatActivity {

    DatabaseHelper databaseHelper;
    ArrayAdapter arrayAdapter;
    ListView lvEquipment;
    SingleLogTest log;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_log_equipment_page);

        Intent intent = getIntent();
        log = (SingleLogTest) intent.getSerializableExtra("singleLogObject");

        lvEquipment = findViewById(R.id.lvSingleEquip);
        databaseHelper = new DatabaseHelper(SingleLogEquipmentPage.this);
        showAllEquipment(databaseHelper);
    }

    private void showAllEquipment(DatabaseHelper databaseHelper2) {
        arrayAdapter = new ArrayAdapter<>(SingleLogEquipmentPage.this, android.R.layout.simple_expandable_list_item_1, databaseHelper2.getSingleEquipment(log));
        lvEquipment.setAdapter(arrayAdapter);
    }
}