package com.example.myapplication;

import android.net.Uri;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.myapplication.databinding.ActivityDcsAlertBinding;

import java.net.URI;
import java.net.URL;

public class activity_dcs_alert extends AppCompatActivity {

    Button back;
    TextView whatIs, symptoms, dan, danLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dcs_alert);

        whatIs = (TextView) findViewById(R.id.tvDcsWhatIs);
        symptoms = (TextView) findViewById(R.id.tvDcsSymptoms);
        dan = (TextView) findViewById(R.id.tvDcsDan);
        back = (Button) findViewById(R.id.dcs_back_button);
        danLink = (TextView) findViewById(R.id.tvDanLink);
        danLink.setMovementMethod(LinkMovementMethod.getInstance());

        String txt_whatIs = "Decompression Sickness (DCS), or \"getting bent\" occurs when Nitrogen " +
                "absorbed by the body at pressure expands more quickly than the body is able to " +
                "naturally expel it. When diving, this can happen when you dive deeper or " +
                "longer than recommended by safe diving limits. While following safe diving guidelines " +
                "can not completely prevent DCS, it can greatly reduce the risk of getting severely bent.";

        String txt_symptoms = "The most common symptoms of DCS are joint pain and numbness/tingling, " +
                "though it can present with a wide range of symptoms that may be hard to identify if " +
                "the case is mild. If you notice any of these symptoms following a dive, let your buddy " +
                "know and consider seeking treatment:\n" +
                "Fatigue, Itchiness, Pain in joints or arm/leg/torso muscles, Dizziness, Ringing in " +
                "the ears, Numbness/tingling, Shortness of breath, Muscle weakness, Difficulty urinating, " +
                "Confusion/personality changes/bizarre behavior, Amnesia, Tremors, Staggering, Coughing " +
                "up blood, Unconsciousness or collapse.";

        String txt_dan = "If you would like more information on DCS, or believe you may be bent and " +
                         "need additional resources, please visit:";

        whatIs.setText(txt_whatIs);
        symptoms.setText(txt_symptoms);
        dan.setText(txt_dan);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

}