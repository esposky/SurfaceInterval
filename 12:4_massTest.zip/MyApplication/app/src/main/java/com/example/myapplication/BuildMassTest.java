package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.example.otherjavafiles.DatabaseHelper;
import com.example.otherjavafiles.DiveDetails;
import com.example.otherjavafiles.DivePartner;
import com.example.otherjavafiles.Equipment;
import com.example.otherjavafiles.EquipmentList;
import com.example.otherjavafiles.LocationDetails;
import com.example.otherjavafiles.SingleLog;
import com.example.otherjavafiles.SingleLogTest;
import com.example.otherjavafiles.WildLife;
import com.example.otherjavafiles.WildLifeList;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BuildMassTest {
    private Random rand = new Random();
    private LocationDetails loc;
    private DiveDetails dive;
    private DivePartner buddy;
    private EquipmentList equipList;
    private WildLifeList wl;
    private DatabaseHelper databaseHelper;

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void get100records(Context context, String userID){
        for (int i = 0; i < 100; i++){
            //location
            String location = "Location " + i;
            String site = "Site " + i;
            int year = rand.nextInt(2021) + 1;
            int month = rand.nextInt(12) + 1;
            int day = rand.nextInt(29) + 1;
            int hour = rand.nextInt(12) + 1;
            int minute = rand.nextInt(60);
            int ampm = rand.nextInt(2);
            loc = new LocationDetails(location, year, month, day, hour, minute, ampm, site);

            //dive details
            int dur = rand.nextInt(101);
            int maxD = rand.nextInt(151);
            int avgD = rand.nextInt(151);
            int temp = rand.nextInt(91);
            int vis = rand.nextInt(101);
            int psiStart = rand.nextInt(4501);
            int psiEnd = rand.nextInt(1001);
            int airType = rand.nextInt(30) + 21;
            String[] cond = new String[] {("Conditions " + i)};
            String[] actv = new String[] {("Activities " + i)};
            boolean naui = rand.nextBoolean();
            dive = new DiveDetails(dur, maxD, avgD, temp, vis, psiStart, psiEnd, airType, cond, actv, naui);

            //buddy
            buddy = new DivePartner(userID, i, "Buddy " + 1, Integer.toString(rand.nextInt(4000)), "Dive Buddy");

            //equipment
            Equipment equip = new Equipment(userID, i, "type " + i, "make " + i,"model " + i, rand.nextBoolean(), rand.nextDouble());
            List<Equipment> list = new ArrayList<Equipment>();
            list.add(equip);
            equipList = new EquipmentList(list);

            WildLife wildlife = new WildLife(userID, i, "Type " + i, "Species " + i);
            Boolean wildlifeInsert = databaseHelper.addNewWildlife(wildlife);
            if (wildlifeInsert) {
                wildlife.setWildlifeID(Integer.parseInt(databaseHelper.getWildlifeId(wildlife)));
            }
            List<WildLife> wlList = new ArrayList<WildLife>();
            wlList.add(wildlife);
            wl = new WildLifeList(wlList);

            SingleLogTest log = new SingleLogTest(loc, dive, buddy, equipList, wl);

            databaseHelper = new DatabaseHelper(context);
            // Try test database add
            Boolean insertLog = databaseHelper.addNewLogTest(log, userID);
            /*if (insertLog) {
                String logID = databaseHelper.getLastAdded();
                Boolean updateWildlifeID = databaseHelper.updateWildlifeID(logID);
                Boolean updateEquipmentID = databaseHelper.updateEquipmentID(logID);
                // If ID is updated correctly
                if (updateWildlifeID && updateEquipmentID) {
                    databaseHelper.insertWildlifeLogTable(wl, logID);
                    databaseHelper.insertEquipmentLogTable(equipList, logID);
                }
            }*/
        }
    }
}
