-----Surface Interval Install Instructions-----

 - To launch Surface Interval from the uncompiled codebase, you will first need an 
Android IDE installed on your computer. For our development, we used Android Studio,
 which is available here: https://developer.android.com/studio/


 - After selecting the link to install the application, accept the terms and 
conditions for the IDE and install it to your system. Once installation is 
completed, launch the IDE. 


 - When prompted to create a new project, select the menu icon in the top-right corner, or "More
Actions" and select "Import Project (Gradle, Eclipse ADT, etc.)", then navigate to the file on 
your system containing the application directory. When you have the "MyApplication" 
folder highlighted, select "Open" in your file explorer to load the entire directory 
into the IDE. It may take a couple of minutes for all of the project files to load into the 
local directory.


 - You may receive an alert that your SDK directory does not match that of the project 
during its initial build, and the option to update this to match your local system. 
Approve this change if prompted to ensure the build is able to compile within your file 
system. If prompted whether you trust the project or not, select that you do trust it.


 - Before you are able to run the application on your computer, you will need to establish 
an Android Virtual Device (AVD) within the IDE for the application to run on. To create this, 
select the dropdown menu in the top-center menu of the IDE that should say "No Devices", then select 
"AVD Manager"


 - Select "+ Create Virtual Device" to open the list of devices that are able to be emulated 
within the IDE. For our development, we used the Google Pixel for all of application testing. 
Once your chosen device for your AVD is selected, click Next at the bottom-right of the page. 


 - Next you will be prompted to select the Android version to run on the AVD. For our testing, 
we used Android R, which is the most recent version available for that device. Select "Download" on the 
Android version, then "Accept", and "Next" to complete the download. Once your version 
is downloaded and installed, click Next again to set the device configuration.


 - No changes are needed on this configuration page, so just select Finish to confirm the AVD setup.
After a moment of the AVD being generated, you will be returned to the AVD Manager page, where you
will now see your configured AVD ready for use. Select the "Play" button on your listed AVD 
(Right-pointing arrow) to launch your AVD in preparation for building the application.


 - Depending on your system, this process may take a few minutes as you see the emulator starting 
up just as a regular mobile device would. At this point, you can close the AVD Manager page 
and return to the IDE.


 - Once the AVD has fully loaded and displays the device's home page, select the green "Play" 
icon in the top-center menu of the IDE to launch the application to the emulator. You will see the 
"Gradle Build Running" notice in the bottom of the IDE letting you know that the code is 
compiling for launch in the emulator. Once the build and install is completed, the application 
will launch automatically to its starting page within the emulator and is ready to use.






