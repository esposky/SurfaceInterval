package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.otherjavafiles.DiveDetails;
import com.example.otherjavafiles.NauiDiveTable;

import java.util.InputMismatchException;

public class DivingInformation1 extends AppCompatActivity {


    private static DiveDetails diveDetails;
    Button continueDiveDetails, back, calcPG;
    EditText duration, maxDepth, avgDepth, temp, visibility, pressureStart, pressureEnd, nitrox_percentage, tvPressureGroupResult;
    String[] activ = new String[5];
    String[] cond;
    RadioButton enter_airType, enter_nitrox, enter_naui, enter_padi;
    CheckBox cbRecreation, cbReef, cbWreck, cbCave, cbSearch;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diving_information1);

        // Grabbing userID from previous page


        duration = (EditText) findViewById(R.id.enter_duration);
        maxDepth = (EditText) findViewById(R.id.enter_max);
        avgDepth = (EditText) findViewById(R.id.enter_avgDepth);
        temp = (EditText) findViewById(R.id.enter_Temp);
        visibility = (EditText) findViewById(R.id.enter_visibility);
        pressureStart = (EditText) findViewById(R.id.enter_pressureStart);
        pressureEnd = (EditText) findViewById(R.id.enter_pressureEnd);
        enter_airType = (RadioButton) findViewById(R.id.airType_radioButton);
        enter_nitrox = (RadioButton) findViewById(R.id.nitrox_radioButton);
        nitrox_percentage = (EditText) findViewById(R.id.nitrox_percentage);
        enter_naui = (RadioButton) findViewById(R.id.naui_radioButton);
        enter_padi = (RadioButton) findViewById(R.id.padi_radioButton);

        // Connect variables to checkboxes
        cbRecreation = findViewById(R.id.recreation_activity);
        cbReef = findViewById(R.id.reef_activity);
        cbWreck = findViewById(R.id.wreck_activity);
        cbCave = findViewById(R.id.cave_activity);
        cbSearch = findViewById(R.id.search_and_recover_activity);

        // Calculate Pressure Group Button and text view
        calcPG = findViewById(R.id.btnCalcPG);
        tvPressureGroupResult = findViewById(R.id.tvPressureGroupResult);

        continueDiveDetails = (Button) findViewById(R.id.continue_next);

        continueDiveDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    createDiveDetails();
                    // Need to be changed here as well
                    //Toast.makeText(DivingInformation1.this, "Pressure Group:" + diveDetails.getPressureGroup(), Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), OtherDivingDetails.class);
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(DivingInformation1.this, e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });

        back = (Button) findViewById(R.id.back_to_locationDetails);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), DivingLocation.class);
                startActivity(intent);
            }
        });

        // Sets button to display the pressure group based on inputs
        calcPG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    createDiveDetails();
                    tvPressureGroupResult.setText("" + diveDetails.getPressureGroup(), TextView.BufferType.EDITABLE);
                    if(diveDetails.getPressureGroup() == '!'){
                        Intent intent = new Intent(getApplicationContext(), activity_dcs_alert.class);
                        startActivity(intent);
                    }
                }catch(Exception e){
                    Toast.makeText(DivingInformation1.this, e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void createDiveDetails(){
        try {
            String input_duration = duration.getText().toString();
            int d = Integer.parseInt(input_duration);
            if(d < 1 || d > 12000)
                throw new InputMismatchException("Must provide a valid dive duration in minutes");
            String input_maxDepth = maxDepth.getText().toString();
            int mD = Integer.parseInt(input_maxDepth);
            if(mD < 1 || mD > 1200)
                throw new InputMismatchException("Must provide a valid maximum dive depth in feet");
            String input_avgDepth = avgDepth.getText().toString();
            int aD = Integer.parseInt(input_avgDepth);
            if(aD < 1 || aD > 1200)
                throw new InputMismatchException("Must provide a valid average dive depth in feet");
            String input_temp = temp.getText().toString();
            int t = Integer.parseInt(input_temp);
            //high temp limit provided for potential commercial dive logging such as nuclear diving
            if(t < 0 || t > 200)
                throw new InputMismatchException("Must provide a valid water temperature in Fahrenheit");
            String input_visibility = visibility.getText().toString();
            int v = Integer.parseInt(input_visibility);
            if(v < 0 || v > 100)
                throw new InputMismatchException("Must provide a valid dive visibility in feet, up to 100 ft");
            String input_pressureStart = pressureStart.getText().toString();
            int pS = Integer.parseInt(input_pressureStart);
            if(pS < 0 || pS > 4600)
                throw new InputMismatchException("Must provide a valid starting gas pressure");
            String input_pressureEnd = pressureEnd.getText().toString();
            int pE = Integer.parseInt(input_pressureEnd);
            if(pE < 0 || pE > 4600)
                throw new InputMismatchException("Must provide a valid ending gas pressure");
            int aT = 21;

            //Nitrox checks for validation and safety
            if(enter_nitrox.isChecked()) {
                aT = Integer.parseInt(nitrox_percentage.getText().toString());
                if (aT < 21 || aT > 50)
                    throw new InputMismatchException("Provided Nitrox mix must be between 21-50%");
                //calc maximum operating depth to prevent validation of unsafe gas mix/depth combination
                double mod = ((1.4/((double)aT / 100)) - 1) * 33;
                if (mD > mod)
                    throw new InputMismatchException("Maximum depth exceeds provided Nitrox mix Maximum Operating Depth");
            }

            // If any box is checked add them to the activities array;
            if (cbRecreation.isChecked()) {
                activ[0] = "Recreation";
            }
            if (cbReef.isChecked()) {
                activ[1] = "Reef";
            }
            if (cbWreck.isChecked()) {
                activ[2] = "Wreck";
            }
            if (cbCave.isChecked()) {
                activ[3] = "Cave";
            }
            if (cbSearch.isChecked()) {
                activ[4] = "Search and Recover";
            }
            diveDetails = new DiveDetails(d, mD, aD, t, v, pS, pE, aT, cond, activ, enter_naui.isChecked());
        } catch(InputMismatchException e) {
            throw e;
        }
        catch(Exception e){
            throw new InputMismatchException("All data fields must be provided accurately");
        }
    }

    public static DiveDetails getData() {
        return diveDetails;
    }
}